package ihm.bd;




import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;
import openk.Projet;

public class openkControl {


	// On pr�pare ici des donn�es dans le programme java, chaque nom utilis� ici sera reli�
	// � un objet javafx, reli� avec le fx:id situ� dans la partie Code de Scene Builder

	// La partie droite de la fen�tre, une liste d'avions
	@FXML
	private TableView<Projet> projetTable;
	// pour laquelle on n'affiche que deux informations (identifiant et nom de l'avion)
	@FXML
	private TableColumn<Projet, String> idColonne;
	@FXML
	private TableColumn<Projet, String> nomColonne;

	// un champs qui permet de montrer l'action du bouton
	@FXML
	private Label texteTest;

	// Les champs de la partie gauche de la fen�tre qui affichent les d�tails 
	// de l'avions actif
	@FXML
	private Label num_utilisateur;
	@FXML
	private Label nom;
	@FXML
	private Label prenom;
	@FXML
	private Label mail;
	@FXML
	private Label tel;

	// Les r�f�rences crois�es vers l'application principale
	private AvionGUI mainApp;

	// La ligne s�lectionn�e dans la liste (par d�faut la premi�re)
	private int ligneActive=0;

	/**
	 * Le constructeur est appel� juste avant la m�thode d'initialisation
	 */
	public openkControl() {  	
	}

	/**
	 * Initializes the controller class.
	 * Cette m�thode est appel�e juste apr�s que la fen�tre ait �t� charg�e
	 */
	@FXML
	private void initialize() {
		// La notation s'appuie sur l'�criture fonctionnelle (lambda) que nous ne 
		// verrons pas en d�tail.
		// Pour faire court : les m�thodes sont appliqu�es pour chaque ligne avec chaque �l�ment de la liste
		// On passe par des SimpleStringProperty pour conserver nos classes m�tier sans javaFX
		idColonne.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getNumero()+""));
		nomColonne.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getNom()));
	}

	/**
	 * Cette m�thode permet de relier le contr�leur principal (reli� au m�tier)
	 * au sous-contr�leur
	 * @param mainApp : l'application principale 
	 */
	public void setMainApp(AvionGUI mainApp) {
		//System.out.println("setMainApp called");
		this.mainApp = mainApp;
		projetTable.setItems(this.mainApp.getProjetData());
		afficheAvionSelection();  
	}

	/**
	 * Mets � jour la partie gauche de la fen�tre avec les d�tails de l'avion actif 
	 */
	private void afficheAvionSelection() {
		Projet projetCourant = projetTable.getItems().get(ligneActive);
		num_utilisateur.setText(projetCourant.getNumero()+"");

		nom.setText(projetCourant.getNom());
		prenom.setText(projetCourant.getPrenom());
		mail.setText(projetCourant.getMail());
		tel.setText(projetCourant.getTel()+"");
	}

	/**
	 * Pour chaque bouton on peut d�finir une m�thode propre associ�e � ce bouton
	 * Dans Scene Builder, � gauche, on clique sur hierarchy, Button
	 * � droite, a �t� indiqu� le nom de la m�thode dans On Action
	 * @param event
	 */
	@FXML
	private void handleButtonAction(ActionEvent event) {
		texteTest.setText("clic (" + ligneActive+")");
	}

	
	/**
	 * � v�rifier
	 * Il serait possible de g�n�rer des petites fen�tres de dialogue
	 * mais actuellement la classe Alert est inconnue (n�cessite javaFX 8u40)
	 * @param event
	 *
	@FXML
	private void handleButtonActionMessage(ActionEvent event) {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Information Dialog");
		alert.setHeaderText("Look, an Information Dialog");
		alert.setContentText("I have a great message for you!");

		alert.showAndWait();
	
		alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Confirmation Dialog");
		alert.setHeaderText("Look, a Confirmation Dialog");
		alert.setContentText("Are you ok with this?");

		Optional<ButtonType> result = alert.showAndWait();
		if (result.get() == ButtonType.OK){
			texteTest.setText("option ok");
		} else {
			texteTest.setText("option cancel");
		}	
	}*/
	@FXML
	private void handleButtonActionMessage(ActionEvent event) {
		texteTest.setText("Alert : inactif");
	}
	
	/**
	 * Pour le MenuButton, on peut d�finir une m�thode propre � chaque ligne associ�e � cette liste
	 * Dans Scene Builder, � gauche, on clique sur hierarchy, Button
	 * � droite, a �t� indiqu� le nom de la m�thode dans On Action
	 * @param event
	 */
	@FXML
	public void handleButtonsListEpaves(ActionEvent event) {
		projetTable.setItems(this.mainApp.getAvionDataEpave());
		afficheAvionSelection(); 
	}

	@FXML
	public void handleButtonsListRestore(ActionEvent event) {
		projetTable.setItems(this.mainApp.getAvionDataAvion());
		afficheAvionSelection(); 
	}

	/**
	 * Pour chaque partie de la fen�tre qui peut �tre manipul�e par la souris,
	 * on peut faire une m�thode.
	 * Celle-ci est indiqu�e dans la partie "code" de TableView :
	 * Dans Scene Builder, � gauche, on clique sur hierarchy, TableView
	 * � droite, a �t� indiqu� le nom de la m�thode dans On Mouse Clicked
	 *   
	 * @param event
	 */
	@FXML
	private void handleMouseTableViewAction(MouseEvent event) {
		// permet de r�cup�rer le num�ro de la ligne s�lectionn�es
		this.setLigneActive(projetTable.getSelectionModel().getSelectedIndex());
		this.afficheAvionSelection();
	}

	/**
	 * Modifie la ligne active
	 * @param ligneSelectionnee
	 */
	public void setLigneActive(int ligneSelectionnee) {
		this.ligneActive=ligneSelectionnee;
	}

}

