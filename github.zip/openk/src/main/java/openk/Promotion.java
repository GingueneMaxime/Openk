package openk;

public class Promotion {

}
