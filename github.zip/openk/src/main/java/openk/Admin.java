package openk;

public class Admin {

}
