package openk;

public class Seance {

}
