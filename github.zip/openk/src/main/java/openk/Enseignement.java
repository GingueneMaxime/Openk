package openk;

public class Enseignement {

}
