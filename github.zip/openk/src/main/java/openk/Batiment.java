package openk;

public class Batiment {

}
