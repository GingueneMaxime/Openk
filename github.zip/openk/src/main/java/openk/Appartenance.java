package openk;

public class Appartenance {

}
