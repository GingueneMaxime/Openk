package openk;

public class Prof {

}
