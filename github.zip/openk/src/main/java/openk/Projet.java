package openk;

import dao.Connexion;

public class Projet {

	public static void main(String[] args) {
		Connexion.getInstance();

	}

}
