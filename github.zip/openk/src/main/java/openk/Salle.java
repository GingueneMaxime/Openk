package openk;

public class Salle {

}
