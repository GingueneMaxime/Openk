package dao;

public enum Alignement {
	Droite, Gauche, Centre;

}

